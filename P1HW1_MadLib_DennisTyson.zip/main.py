first_name = input()
generic_location = input()
whole_number = int(input())
plural_noun = input()

print(first_name, 'went to', generic_location, 'to buy', whole_number, 'different types of', plural_noun)